package com.vipnumber.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

data class VipNumber(
    val number: String,
    val price: String,
    val tag: String = ""
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                VipApp()
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VipApp() {
    val numbers = remember {
        listOf(
            VipNumber(number = "+91 8400 91 8400", price = "₹40,000 (Fixed)", tag = "NEAR RTP"),
            VipNumber(number = "70036 70035", price = "₹10,000", tag = "Combo"),
            VipNumber(number = "87772 77767", price = "₹8,000"),
            VipNumber(number = "99181 71615", price = "₹10,000")
        )
    }
    Scaffold(
        topBar = { SmallTopAppBar(title = { Text("VIP Number App") }) }
    ) { padding ->
        Column(Modifier.padding(padding)) {
            HeroCard()
            Divider()
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(numbers) { item -> VipCard(item) }
            }
        }
    }
}

@Composable
fun HeroCard() {
    Card(Modifier.fillMaxWidth().padding(12.dp)) {
        Column(Modifier.padding(16.dp)) {
            Text("👑 Exclusive VIP Number Drop", fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(4.dp))
            Text("Premium Class • NEAR RTP", fontSize = 14.sp)
            Spacer(Modifier.height(8.dp))
            Text("+91 8400 91 8400", fontSize = 28.sp, fontWeight = FontWeight.Black, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(6.dp))
            Text("₹40,000 Only (Fixed)", fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                ActionButton(label = "WhatsApp", url = "https://wa.me/918400918400?text=Hi%2C%20I'm%20interested%20in%20+91%208400%2091%208400")
                ActionButton(label = "Call", dial = "+918400918400")
            }
        }
    }
}

@Composable
fun VipCard(item: VipNumber) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp)) {
            Text(item.number, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            if (item.tag.isNotBlank()) {
                Spacer(Modifier.height(4.dp))
                AssistChip(onClick = {}, label = { Text(item.tag) })
            }
            Spacer(Modifier.height(6.dp))
            Text(item.price, fontSize = 16.sp, fontWeight = FontWeight.Medium)
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                val last10 = item.number.filter { it.isDigit() }.takeLast(10)
                ActionButton(label = "WhatsApp", url = "https://wa.me/91$last10?text=Hi%2C%20Interested%20in%20${item.number}")
                ActionButton(label = "Call", dial = "+91$last10")
            }
        }
    }
}

@Composable
fun ActionButton(label: String, url: String? = null, dial: String? = null) {
    val context = androidx.compose.ui.platform.LocalContext.current
    Button(onClick = {
        when {
            url != null -> context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
            dial != null -> context.startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:$dial")))
        }
    }) { Text(label) }
}
